#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, a, b;
    int *xp, *yp, *zp;

    printf("Enter the size of each vector: \n");
    scanf("%d", &n);

    printf("Enter the values for coefficients a and b:\n");
    scanf("%d %d", &a, &b);

    xp = (int*) malloc(n * sizeof(int));
    

    printf("Enter the values of x vector:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &xp[i]);
    }

    yp = (int*) malloc(n * sizeof(int));
    

    printf("Enter the values of y vector:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &yp[i]);
    }

    zp = (int*) malloc(n * sizeof(int));
  

    printf("The result is:\n");
    for (int i = 0; i < n; i++) {
        zp[i] = a * xp[i] + b * yp[i];
        printf("%d ", zp[i]);
    }
    printf("\n");

    free(xp);
    free(yp);
    free(zp);

    return 0;
}


#include <stdio.h>
#include <stdlib.h>

int main() {



	int n, i, *ptr, sum = 0;

	printf("Enter number of elemnts: ");
	scanf("%d", &n);

	ptr = (int*) malloc(n*sizeof(int));

	if (ptr ==NULL) {
		printf("failed");
		return 1;
	}

	printf("enter elements: ");
	for (i=0; i<n; i++) {

		scanf("%d", ptr + i);
		sum = sum + ptr[i];
	}

	printf("sum = %d", sum);

	free(ptr);





	return 0;

}
